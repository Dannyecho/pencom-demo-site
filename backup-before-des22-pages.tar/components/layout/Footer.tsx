import { Link } from "react-router";
import {
  Mail, Phone, MapPin, ExternalLink, ArrowRight,
  Apple, Play, Facebook, Twitter, Linkedin, Instagram, Youtube
} from "lucide-react";

const footerLinks = {
  "About PenCom": [
    { label: "About the Commission", href: "/about" },
    { label: "Mission & Vision", href: "/about#mission" },
    { label: "Leadership", href: "/about#executive" },
    { label: "Service Charter", href: "/about#charter" },
  ],
  Services: [
    { label: "Pension Services", href: "/services" },
    { label: "RSA Transfer", href: "/services#rsa-transfer" },
    { label: "Personal Pension Plan", href: "/services#ppp" },
    { label: "Pension Clearance", href: "/services#pcc" },
  ],
  Resources: [
    { label: "Publications", href: "/resources#publications" },
    { label: "PenCom Chronicles", href: "/chronicles" },
    { label: "Photos and videos", href: "/media" },
    { label: "Circulars", href: "/regulations?type=Circular#library" },
    { label: "Downloads", href: "/resources#downloads" },
    { label: "FAQs", href: "/resources/faq" },
    { label: "Admin Dashboard", href: "/admin" },
  ],
};

const socialLinks = [
  { icon: Twitter, href: "https://x.com/PenComNig", label: "X (Twitter)" },
  { icon: Instagram, href: "https://instagram.com/pencomnigeria", label: "Instagram" },
  { icon: Facebook, href: "https://facebook.com/PenCom.gov", label: "Facebook" },
  { icon: Youtube, href: "https://youtube.com/channel/UCK7FCj7J1GMk6hrnDDInq9w", label: "YouTube" },
  { icon: Linkedin, href: "https://linkedin.com/company/national-pension-commission", label: "LinkedIn" },
];

export default function Footer() {
  return (
    <footer className="bg-[#0A4A13] text-white">
      {/* Top Green Band: Newsletter + Get the App */}
      <div className="bg-[#117F21]">
        <div className="max-w-7xl mx-auto px-4 py-10">
          <div className="grid md:grid-cols-2 gap-10">
            {/* Newsletter Signup */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Sign up for our newsletter</h3>
              <div className="flex gap-3">
                <div className="flex-1 relative">
                  <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-white/40" />
                  <input
                    type="email"
                    placeholder="Email......"
                    className="w-full bg-white/10 border border-white/20 rounded-lg pl-10 pr-4 py-2.5 text-sm text-white placeholder:text-white/40 outline-none focus:border-[#CB9615] focus-visible:ring-2 focus-visible:ring-[#CB9615] focus-visible:ring-offset-2 focus-visible:ring-offset-[#117F21] transition-colors"
                  />
                </div>
                <button className="px-5 py-2.5 bg-[#0A4A13] text-white text-sm font-semibold rounded-lg hover:bg-[#0d3d15] active:scale-95 transition-all flex items-center gap-2 shrink-0 focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[#117F21] outline-none cursor-pointer">
                  Sign up
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Get the App */}
            <div>
              <h3 className="text-lg font-semibold mb-4">Get the app</h3>
              <div className="flex gap-3">
                <Link
                  to="/mobile"
                  className="inline-flex items-center gap-2.5 px-4 py-2.5 bg-[#0A4A13] text-white rounded-lg hover:bg-[#0d3d15] transition-colors"
                >
                  <Apple className="w-5 h-5" />
                  <div className="text-left">
                    <p className="text-[9px] opacity-70 leading-none">Download on the</p>
                    <p className="text-xs font-semibold leading-tight">App Store</p>
                  </div>
                </Link>
                <Link
                  to="/mobile"
                  className="inline-flex items-center gap-2.5 px-4 py-2.5 bg-[#0A4A13] text-white rounded-lg hover:bg-[#0d3d15] transition-colors"
                >
                  <Play className="w-5 h-5" />
                  <div className="text-left">
                    <p className="text-[9px] opacity-70 leading-none">GET IT ON</p>
                    <p className="text-xs font-semibold leading-tight">Google Play</p>
                  </div>
                </Link>
              </div>

              {/* Social Icons */}
              <div className="flex items-center gap-3 mt-6">
                {socialLinks.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/25 transition-colors focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[#0A4A13] outline-none"
                    aria-label={social.label}
                  >
                    <social.icon className="w-4 h-4" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main footer links */}
      <div className="max-w-7xl mx-auto px-4 py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-4">
              <img
                src="/pencom-logo.png"
                alt="PenCom Logo"
                className="w-10 h-10 rounded-lg object-contain bg-white/10"
              />
              <div>
                <div className="font-bold leading-tight">PenCom</div>
                <div className="text-xs text-white/60">National Pension Commission</div>
              </div>
            </div>
            <p className="text-sm text-white/70 leading-relaxed mb-4">
              Ensuring the safety and security of retirement benefits for all Nigerian workers through effective regulation and supervision of the pension industry.
            </p>
            <div className="space-y-2 text-sm text-white/60">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 shrink-0" />
                174, Adetokunbo Ademola Crescent, Wuse II, Abuja
              </div>
              <div className="flex items-center gap-2">
                <Phone className="w-4 h-4 shrink-0" />
                09-4611300, 0700-PENCOM (0700-736266)
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 shrink-0" />
                info@pencom.gov.ng
              </div>
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-semibold text-sm mb-4">{title}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.href}
                      className="text-sm text-white/60 hover:text-white transition-colors focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[#0A4A13] rounded outline-none px-1 -mx-1"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* External portals */}
        <div className="mt-10 pt-8 border-t border-white/10">
          <h4 className="text-sm font-semibold mb-3">External Portals</h4>
          <div className="flex flex-wrap gap-3">
            {["COBRA", "Pencare", "PENCAP", "PCRS"].map((portal) => (
              <a
                key={portal}
                href={`https://${portal.toLowerCase()}.pencom.gov.ng`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-white/10 rounded-lg text-sm text-white/80 hover:bg-white/20 transition-colors"
              >
                {portal}
                <ExternalLink className="w-3 h-3" />
              </a>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 py-4 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-xs text-white/50">
            &copy; 2026 National Pension Commission. All rights reserved. Federal Republic of Nigeria.
          </p>
          <div className="flex items-center gap-4">
            <Link to="/connect" className="text-xs text-white/50 hover:text-white transition-colors">
              Contact Us
            </Link>
            <span className="text-white/20">|</span>
            <Link to="/connect#report" className="text-xs text-white/50 hover:text-white transition-colors">
              Report Employer
            </Link>
            <span className="text-white/20">|</span>
            <Link to="/regulations#policies" className="text-xs text-white/50 hover:text-white transition-colors">
              Privacy Policy
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
