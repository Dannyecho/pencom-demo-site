import { useEffect, useRef, useState } from "react";
import { Link, useNavigate } from "react-router";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { ArrowRight, ChevronLeft, ChevronRight, Pause, Play, Sparkles } from "lucide-react";
import ReportGovBadge from "@/components/ReportGovBadge";
import { useI18n } from "@/i18n/context";
import { GridBackdrop, ease } from "@/pages/about/primitives";
import { popularTasks, slides } from "./data";
import SiteSearch, { go } from "./SiteSearch";

const SLIDE_MS = 8000;
const pad = (n: number) => String(n).padStart(2, "0");

/**
 * Hero slider following brief §7.1: live HTML text, prev/next + "Slide x of y" + pause,
 * ≥7s per slide, pauses on hover/focus, stops after one full cycle, never auto-advances
 * under reduced motion, swipe on touch. Search sits beside it so tasks come first.
 */
export default function HomeHero() {
  const { t, lang } = useI18n();
  const reduce = useReducedMotion();
  const navigate = useNavigate();
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [hold, setHold] = useState(false); // hover or focus inside the slider
  const [announce, setAnnounce] = useState("");
  const [dir, setDir] = useState(1); // 1 = forward, -1 = back
  const touchX = useRef<number | null>(null);

  useEffect(() => {
    if (reduce) setPlaying(false);
  }, [reduce]);

  const goTo = (i: number, user = true) => {
    setDir(i < index ? -1 : 1);
    const n = (i + slides.length) % slides.length;
    setIndex(n);
    if (user) setAnnounce(t("Slide {n} of {total}: {title}", { n: n + 1, total: slides.length, title: t(slides[n].title) }));
  };

  // Loops endlessly (client request); the visible Pause button keeps WCAG 2.2.2 satisfied.
  const onBarDone = () => goTo(index + 1, false);

  const running = playing && !hold && !reduce;
  const slide = slides[index];

  return (
    <section aria-label="Featured" className="relative isolate overflow-hidden bg-[#04240A] text-white">
      {/* Background slides */}
      <AnimatePresence initial={false} custom={dir}>
        <motion.div
          key={index}
          custom={dir}
          variants={{
            enter: (d: number) => ({ opacity: 0, x: reduce ? 0 : `${d * 8}%` }),
            center: { opacity: 1, x: "0%" },
            exit: (d: number) => ({ opacity: 0, x: reduce ? 0 : `${d * -8}%` }),
          }}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{ duration: reduce ? 0 : 1.1, ease }}
          className="absolute inset-0 -z-20"
        >
          <motion.img
            src={slide.image}
            alt={slide.alt}
            initial={{ scale: reduce ? 1 : 1.08 }}
            animate={{ scale: running ? 1 : 1.04 }}
            transition={{ duration: running ? SLIDE_MS / 1000 : 0.6, ease: "linear" }}
            className="h-full w-full object-cover"
            style={{ objectPosition: slide.position }}
            fetchPriority={index === 0 ? "high" : "auto"}
          />
        </motion.div>
      </AnimatePresence>
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-gradient-to-r from-[#04240A] via-[#04240A]/85 to-[#04240A]/20" />
      <div aria-hidden="true" className="absolute inset-0 -z-10 bg-gradient-to-t from-[#04240A] via-transparent to-[#04240A]/30" />
      <GridBackdrop className="-z-10 opacity-50" />
      <div aria-hidden="true" className="absolute -left-40 top-20 -z-10 h-[480px] w-[480px] rounded-full bg-[#117F21] opacity-40 blur-[140px]" />

      <h1 className="sr-only">National Pension Commission</h1>
      <div className="mx-auto max-w-7xl px-4 pb-10 pt-4">
        <div className="flex items-center justify-between">
          <ReportGovBadge />
        </div>

        <div className="grid grid-cols-1 min-h-[560px] items-center gap-10 py-10 lg:grid-cols-12 lg:py-14">
          {/* ── Slide copy ── */}
          <div
            className="lg:col-span-7"
            role="region"
            aria-roledescription="carousel"
            aria-label="Featured announcements"
            onPointerEnter={() => setHold(true)}
            onPointerLeave={() => setHold(false)}
            onFocus={() => setHold(true)}
            onBlur={(e) => !e.currentTarget.contains(e.relatedTarget as Node) && setHold(false)}
            onTouchStart={(e) => (touchX.current = e.touches[0].clientX)}
            onTouchEnd={(e) => {
              if (touchX.current === null) return;
              const dx = e.changedTouches[0].clientX - touchX.current;
              if (Math.abs(dx) > 50) goTo(index + (dx < 0 ? 1 : -1));
              touchX.current = null;
            }}
          >
            <div className="relative min-h-[300px] sm:min-h-[280px]">
              <AnimatePresence mode="popLayout" initial={false} custom={dir}>
                <motion.div
                  key={index}
                  role="group"
                  aria-roledescription="slide"
                  aria-label={`${index + 1} of ${slides.length}`}
                  custom={dir}
                  variants={{
                    enter: (d: number) => ({ opacity: 0, x: reduce ? 0 : d * 80 }),
                    center: { opacity: 1, x: 0 },
                    exit: (d: number) => ({ opacity: 0, x: reduce ? 0 : d * -80, transition: { duration: 0.35, ease } }),
                  }}
                  initial="enter"
                  animate="center"
                  exit="exit"
                  transition={{ duration: 0.6, ease }}
                  className="w-full"
                >
                  <motion.span
                    initial={{ opacity: 0, x: reduce ? 0 : -12 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, ease }}
                    className="inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-1.5 text-xs font-semibold uppercase tracking-[0.18em] text-[#F4D27A] backdrop-blur"
                  >
                    <Sparkles className="h-3.5 w-3.5" aria-hidden="true" />
                    {slide.eyebrow}
                  </motion.span>
                  <h2 data-i18n-done={lang !== "en" ? "" : undefined} className="mt-6 text-[2.5rem] font-bold leading-[1.05] tracking-tight sm:text-6xl lg:text-[4rem]">
                    {t(slide.title).split(" ").map((w, i) => (
                      <span key={i} className="inline-block overflow-hidden pb-1 align-bottom">
                        <motion.span
                          className="inline-block"
                          initial={{ y: reduce ? 0 : "105%" }}
                          animate={{ y: 0 }}
                          transition={{ duration: 0.7, delay: 0.08 + i * 0.06, ease }}
                        >
                          {w}
                        </motion.span>
                        {" "}
                      </span>
                    ))}
                  </h2>
                  <motion.p
                    initial={{ opacity: 0, y: reduce ? 0 : 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.35, ease }}
                    className="mt-5 max-w-xl text-lg leading-relaxed text-white/75"
                  >
                    {slide.summary}
                  </motion.p>
                  <motion.div
                    initial={{ opacity: 0, y: reduce ? 0 : 12 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.6, delay: 0.45, ease }}
                    className="mt-8"
                  >
                    <button
                      type="button"
                      onClick={() => go(slide.cta, navigate)}
                      className="group inline-flex min-h-12 items-center gap-2 rounded-xl bg-[#CB9615] px-6 py-3 font-semibold text-[#1A1206] shadow-[0_10px_30px_-10px_rgba(203,150,21,0.8)] transition hover:bg-[#E0AA22] focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-offset-2 focus-visible:outline-[#FFD84D]"
                    >
                      {slide.cta.label}
                      <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
                    </button>
                  </motion.div>
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Controls */}
            <div className="mt-10 flex flex-wrap items-center gap-4">
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => goTo(index - 1)}
                  aria-label="Previous slide"
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 bg-white/5 backdrop-blur transition hover:bg-white/20 focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[#FFD84D]"
                >
                  <ChevronLeft className="h-5 w-5" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => goTo(index + 1)}
                  aria-label="Next slide"
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 bg-white/5 backdrop-blur transition hover:bg-white/20 focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[#FFD84D]"
                >
                  <ChevronRight className="h-5 w-5" aria-hidden="true" />
                </button>
                <button
                  type="button"
                  onClick={() => setPlaying((p) => !p)}
                  aria-label={playing ? "Pause slides" : "Play slides"}
                  className="flex h-11 w-11 items-center justify-center rounded-full border border-white/20 bg-white/5 backdrop-blur transition hover:bg-white/20 focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[#FFD84D]"
                >
                  {playing ? <Pause className="h-4 w-4" aria-hidden="true" /> : <Play className="h-4 w-4" aria-hidden="true" />}
                </button>
              </div>

              {/* Segmented progress */}
              <div className="flex items-center gap-2" aria-hidden="true">
                {slides.map((_, i) => (
                  <button
                    key={i}
                    type="button"
                    tabIndex={-1}
                    onClick={() => goTo(i)}
                    className="relative h-1.5 w-10 overflow-hidden rounded-full bg-white/20 sm:w-14"
                  >
                    {i < index && <span className="absolute inset-0 bg-white/70" />}
                    {i === index && (
                      <motion.span
                        key={`${index}-${running}`}
                        className="absolute inset-y-0 left-0 bg-[#F4D27A]"
                        initial={{ width: running ? "0%" : "100%" }}
                        animate={{ width: "100%" }}
                        transition={{ duration: running ? SLIDE_MS / 1000 : 0, ease: "linear" }}
                        onAnimationComplete={() => running && onBarDone()}
                      />
                    )}
                  </button>
                ))}
              </div>
              <p className="font-mono text-sm text-white/60">
                <span className="sr-only">Slide </span>
                <span className="text-white">{pad(index + 1)}</span>
                <span className="sr-only"> of </span>
                <span aria-hidden="true"> / </span>
                {pad(slides.length)}
              </p>
            </div>
            <p className="sr-only" aria-live="polite">
              {announce}
            </p>
          </div>

          {/* ── Search card ── */}
          <motion.div
            initial={{ opacity: 0, y: reduce ? 0 : 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3, ease }}
            className="lg:col-span-5"
          >
            <div className="relative rounded-3xl border border-white/15 bg-white/[0.08] p-6 shadow-[0_40px_80px_-40px_rgba(0,0,0,0.8)] backdrop-blur-xl sm:p-8">
              <span aria-hidden="true" className="absolute inset-x-8 -top-px h-px bg-gradient-to-r from-transparent via-[#F4D27A]/70 to-transparent" />
              <h2 className="text-2xl font-bold">What do you need to do today?</h2>
              <p className="mt-2 text-sm text-white/65">Search tasks, services, regulations and answers.</p>
              <div className="mt-5">
                <SiteSearch dark />
              </div>
              <p className="mt-6 text-xs font-semibold uppercase tracking-[0.18em] text-white/50">Popular</p>
              <ul className="mt-3 flex flex-wrap gap-2">
                {popularTasks.map((t) => (
                  <li key={t.label}>
                    <Link
                      to={t.href}
                      className="inline-flex min-h-10 items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-4 text-sm font-medium text-white/90 transition hover:border-[#F4D27A]/60 hover:bg-white/15 hover:text-white focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[#FFD84D]"
                    >
                      {t.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
