import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { AlertTriangle, CheckCircle, ChevronLeft, ChevronRight, Info, Shield, X } from "lucide-react";
import { useI18n } from "@/i18n/context";
import { cn } from "@/lib/utils";

type AlertType = "critical" | "warning" | "info" | "success";

interface SiteAlert {
  id: string;
  type: AlertType;
  title: string;
  message: string;
}

// Content owner: Corporate Communications. Give each alert a new id when its wording changes,
// so readers who closed the old one see the new one.
const siteAlerts: SiteAlert[] = [
  {
    id: "remit-by-7th-2026",
    type: "critical",
    title: "Important Update",
    message: "All employers must remit pension contributions by the 7th of every month. Non-compliance will attract penalties under the Pension Reform Act 2014.",
  },
  {
    id: "retiree-verification-portal",
    type: "info",
    title: "New Digital Portal",
    message: "PenCom has launched a new online verification portal for retirees. Visit the Services page to learn more.",
  },
  {
    id: "kyc-update-dec-2026",
    type: "warning",
    title: "Verification Exercise",
    message: "All RSA holders are advised to update their KYC information with their respective PFAs before December 31, 2026.",
  },
];

const style: Record<AlertType, { bg: string; icon: typeof Info; label: string }> = {
  critical: { bg: "from-[#8E1A1E] via-[#B52026] to-[#D32F2F]", icon: Shield, label: "Critical" },
  warning: { bg: "from-[#92400E] via-[#B45309] to-[#D97706]", icon: AlertTriangle, label: "Warning" },
  info: { bg: "from-[#0D47A1] via-[#1565C0] to-[#1E88E5]", icon: Info, label: "Information" },
  success: { bg: "from-[#0A4A13] via-[#117F21] to-[#2E913D]", icon: CheckCircle, label: "Update" },
};

const KEY = "pencom:alerts-closed";
const readClosed = (): string[] => {
  try {
    return JSON.parse(window.localStorage.getItem(KEY) ?? "[]");
  } catch {
    return [];
  }
};

/**
 * Site alerts (home page). Alerts never close or change on their own: each stays until the reader
 * closes it with ×, and readers step through several alerts themselves (WCAG 2.2.1, 2.2.2).
 * Closed alerts are remembered on this device.
 */
export default function AlertBanner() {
  const { t } = useI18n();
  const reduce = useReducedMotion();
  const [closed, setClosed] = useState<string[]>(readClosed);
  const open = siteAlerts.filter((a) => !closed.includes(a.id));
  const [i, setI] = useState(0);
  const [dir, setDir] = useState(1);
  const idx = Math.min(i, Math.max(open.length - 1, 0));
  const current = open[idx];

  useEffect(() => {
    try {
      window.localStorage.setItem(KEY, JSON.stringify(closed));
    } catch {
      /* storage unavailable */
    }
  }, [closed]);

  const step = (d: number) => {
    setDir(d);
    setI((idx + d + open.length) % open.length);
  };
  const close = () => {
    if (!current) return;
    setDir(1);
    setClosed((c) => [...c, current.id]);
    setI(Math.min(idx, open.length - 2));
  };

  const s = current ? style[current.type] : style.info;
  const Icon = s.icon;

  return (
    <AnimatePresence initial={false}>
      {current && (
        <motion.section
          key="alerts"
          aria-label={t("Site alerts")}
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: "auto", opacity: 1 }}
          exit={{ height: 0, opacity: 0 }}
          transition={{ duration: reduce ? 0 : 0.4, ease: "easeInOut" }}
          className="relative z-[40] overflow-hidden"
        >
          <motion.div layout className={cn("relative bg-gradient-to-r text-white transition-colors duration-500", s.bg)}>
            {/* soft moving sheen, decorative only */}
            {!reduce && (
              <motion.div
                aria-hidden="true"
                className="pointer-events-none absolute inset-y-0 w-1/3 bg-gradient-to-r from-transparent via-white/10 to-transparent"
                initial={{ x: "-100%" }}
                animate={{ x: "400%" }}
                transition={{ duration: 2.4, delay: 0.6, ease: "easeInOut" }}
              />
            )}
            <div className="relative mx-auto flex max-w-7xl items-start gap-3 px-4 py-3 sm:items-center">
              <span className="relative mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-white/15 ring-1 ring-white/25 sm:mt-0">
                {current.type === "critical" && !reduce && <span aria-hidden="true" className="absolute inset-0 animate-ping rounded-full bg-white/20 [animation-duration:2.4s] [animation-iteration-count:3]" />}
                <Icon className="relative h-4 w-4" aria-hidden="true" />
              </span>

              <div className="min-w-0 flex-1" aria-live="polite" aria-atomic="true">
                <AnimatePresence mode="wait" initial={false} custom={dir}>
                  <motion.div
                    key={current.id}
                    initial={{ opacity: 0, x: reduce ? 0 : 16 * dir }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: reduce ? 0 : -16 * dir }}
                    transition={{ duration: 0.25 }}
                    className="flex flex-col gap-1 sm:flex-row sm:items-baseline sm:gap-2"
                  >
                    <span className="flex shrink-0 items-center gap-2">
                      <span className="rounded-full bg-black/20 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider">{t(s.label)}</span>
                      <span className="text-xs font-bold uppercase tracking-wider">{t(current.title)}</span>
                    </span>
                    <span className="text-sm leading-snug text-white/95">{t(current.message)}</span>
                  </motion.div>
                </AnimatePresence>
              </div>

              <div className="flex shrink-0 items-center gap-1">
                {open.length > 1 && (
                  <>
                    <button type="button" onClick={() => step(-1)} aria-label={t("Previous alert")} className="hidden h-9 w-9 items-center justify-center rounded-full hover:bg-white/15 focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[#FFD84D] sm:flex">
                      <ChevronLeft className="h-4 w-4" aria-hidden="true" />
                    </button>
                    <span className="min-w-10 text-center text-xs font-semibold tabular-nums text-white/85">
                      <span className="sr-only" data-i18n-done>{t("Alert {n} of {total}", { n: idx + 1, total: open.length })}</span>
                      <span aria-hidden="true">{idx + 1} / {open.length}</span>
                    </span>
                    <button type="button" onClick={() => step(1)} aria-label={t("Next alert")} className="flex h-9 w-9 items-center justify-center rounded-full hover:bg-white/15 focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[#FFD84D]">
                      <ChevronRight className="h-4 w-4" aria-hidden="true" />
                    </button>
                  </>
                )}
                <button
                  type="button"
                  onClick={close}
                  aria-label={t("Close this alert")}
                  title={t("Close this alert")}
                  className="ml-1 flex h-9 w-9 items-center justify-center rounded-full bg-white/10 ring-1 ring-white/25 transition hover:rotate-90 hover:bg-white/25 focus-visible:outline focus-visible:outline-[3px] focus-visible:outline-[#FFD84D]"
                >
                  <X className="h-4 w-4" aria-hidden="true" />
                </button>
              </div>
            </div>
          </motion.div>
        </motion.section>
      )}
    </AnimatePresence>
  );
}
