import { Routes, Route } from 'react-router'
import Layout from './components/layout/Layout'
import Home from './pages/Home'
import About from './pages/About'
import Services from './pages/Services'
import Operators from './pages/Operators'
import Resources from './pages/Resources'
import Regulations from './pages/Regulations'
import Connect from './pages/Connect'
import AdminDashboard from './pages/admin/Dashboard'
import MobileApp from './pages/MobileApp'
import Performance from './pages/Performance'

export default function App() {
  return (
    <Routes>
      {/* Main website with Layout (Header + Footer + Chatbot) */}
      <Route element={<Layout />}>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/operators" element={<Operators />} />
        <Route path="/resources" element={<Resources />} />
        <Route path="/resources/faq" element={<Resources />} />
        <Route path="/regulations" element={<Regulations />} />
        <Route path="/connect" element={<Connect />} />
        <Route path="/performance" element={<Performance />} />
      </Route>
      {/* Standalone routes (no Layout) */}
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/mobile" element={<MobileApp />} />
    </Routes>
  )
}
